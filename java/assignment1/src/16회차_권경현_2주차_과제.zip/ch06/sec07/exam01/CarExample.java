package ch06.sec07.exam01;

public class CarExample {
    public static void main(String[] args) {
        Car myCar=new Car("Granduer","black",250);
    }
}
