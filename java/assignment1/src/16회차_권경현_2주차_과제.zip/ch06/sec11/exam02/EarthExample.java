package ch06.sec11.exam02;

public class EarthExample {
    public static void main(String[] args) {
        System.out.println("Earth Example "+Earth.surf);
    }
}
