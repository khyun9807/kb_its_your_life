package ch06.sec11.exam02;

public class Earth {
    static final double PI = 3.14f;
    static final long radius=64000;
    static final double surf;
    static{
        surf=radius*radius*4*PI;
    }
}
