package ch06.sec09;

public class CarExample {
    public static void main(String[] args) {
        Car c1=new Car("coupe");

        c1.setSpeed(100);

        c1.run();
    }
}
